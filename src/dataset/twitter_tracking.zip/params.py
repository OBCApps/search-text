#Variables that contains the user credentials for the Twitter API 
bearer_token = "AAAAAAAAAAAAAAAAAAAAAOqHggEAAAAAa25Ot%2Bb%2BgfkBXCouBJEcaEQWq%2Bk%3DE3SU4HwGqocG0ZKZncd7b8fxZA3DWb6xtxqhmpyJkFFm7Oi8by"
api_key = "tWPw2rhCKgoHyacPhrIDm6YDx"
api_key_secret = "pVaeQYkeO4rnCNeZKkrmRzCT2FesXloRfT9YOextDE3gA2ssLq"

#destination folder for raw tweets 
folder_path = "raw/"
#destination folder for clean tweets
clean_path = "clean/"

# the list of tracking words 
tracklist = [    
    'computación',    
    'RPP'
]
